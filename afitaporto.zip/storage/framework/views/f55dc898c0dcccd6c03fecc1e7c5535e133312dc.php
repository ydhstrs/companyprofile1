<?php $__env->startSection('contents'); ?>
    <header id="" class="py-28 text-center md:pt-10 lg:text-left ">
        <div class="container px-1 sm:px-8 lg:grid lg:grid-cols-2 lg:gap-x-8">
                        <div class="xl:text-right pt-48">
                <?php $__currentLoopData = $about; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img class="transition ease-in-out delay-150 hover:-translate-y-1 hover:scale-125 duration-300"src="<?php echo e(asset('storage/' . $item->image)); ?>" alt="alternative" width="70%"/>
                <div class="flex items-center mt-10">
                    <h4 class="font-light text-slate-700 py-4 px-4 font-Amiri">Check Out My : </h4>
                    <a href="https://<?php echo e($item->instagram); ?>" target="_blank"
                        class="w-10 h-10 mr-3 rounded-full flex justify-center items-center
              text-slate-400 ">
                        <img class="h-10 self-center transition ease-in-out delay-150 hover:-translate-y-1 hover:scale-125 duration-300" src="/images/instagram.png" />
                    </a>
                    <a href="https://<?php echo e($item->linkedin); ?>" target="_blank"
                        class="w-10 h-10 mr-3 rounded-full flex justify-center items-center
              text-slate-400 ">
                        <img class="h-10 self-center transition ease-in-out delay-150 hover:-translate-y-1 hover:scale-125 duration-300" src="/images/linkedin.png" />
                    </a>
                        <a href="https://<?php echo e($item->tiktok); ?>" target="_blank"
                            class="w-10 h-10 mr-3 rounded-full flex justify-center items-center
                  text-slate-400 ">
                            <img class="h-10 self-center transition ease-in-out delay-150 hover:-translate-y-1 hover:scale-125 duration-300" src="/images/tiktok.png" />
                        </a>
                </div>
            </div>
            <div class="mb-16 lg:mt-32 xl:mt-40 xl:mr-12">
                <h1 class="text-base text-primary1 font-bold md:text-xl lg:text-4xl col-start-1 pb-4 font-Akira">
                    ABOUT ME

                </h1>
                    <p class="pre-line light text-gray-700 mb-10 font-Amiri">
                        <?php echo e($item->isi); ?>

                    </p>
                <a target="blank" href="https://mail.google.com/mail/u/0/?fs=1&tf=cm&to=<?php echo e($item->email); ?>"
                    class="text-lg font-Amiri text-white bg-fourth1 py-1 px-9 rounded-xl hover:shadow-md hover:opacity-80 transition duration-500 ease-in-out">
                    Email Me</a>
                    <a href="<?php echo e(asset('storage/' . $item->cv)); ?>" download="resume-afita" class="text-lg font-Amiri text-fourth1 underline underline-offset-4 py-3 px-9 hover:shadow-md hover:opacity-80 transition duration-500 ease-in-out">
                         Download CV
</a>

            </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        </div> <!-- end of container -->
    </header> <!-- end of header -->
    <!-- About Section Start -->
    <section id="about" class="pt-20">
        <div class="container">
            <div class="flex justify-center">
                <div class="mb-6 w-full px-4">
            <div class="xl:text-right pt-20">
                <?php $__currentLoopData = $cv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img class=""
                        src="<?php echo e(asset('storage/' . $item->image)); ?>" alt="alternative" />
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

                </div>

            </div>

    </section>
    <!-- About Section End -->
        <div class="mb-16 pt-32">
            <h4 class="font-Akira text-4xl text-primary1 text-center mb-2">  <span class="text-xs font-thin">- - - - - - - - - - - - - - - - - - - - - -</span> TOOLS & SKILLS <span class="text-xs font-thin">- - - - - - - - - - - - - - - - - - - - - -</span></h4>
        </div>
        <div class="flex justify-center gap-4 mx-auto mb-40">
            <?php $__currentLoopData = $tools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <img class="w-20 h-20"
                        src="<?php echo e(asset('storage/' . $item->image)); ?>" alt="afita tool" />
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
  
  
    <section id="contact">

        <div class="py-16 min-w-full flex transition-all duration-500 bg-third1 pt-30">
            <div class="container max-w-screen-lg mx-auto">
                <div class="text-center">
                    <div class="">
                        <p class="text-2xl font-bold text-black mb-4 font-Akira">
                            GET IN TOUCH WITH ME, SAY HI
                        </p>
                        <?php $__currentLoopData = $about; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a target="blank" href="https://mail.google.com/mail/u/0/?fs=1&tf=cm&to=<?php echo e($item->email); ?>"
                                class="text-2xl text-fourth1 underline underline-offset-8 font-Amiri font-semibold">
                                <ion-icon class="text-xl" name="mail-outline"></ion-icon><?php echo e($item->email); ?>

                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>
                <hr class="my-6  sm:mx-auto text-white lg:my-8" />

            </div>
        </div>
    </section>
    <style>
        .platform {
            position: relative;
            transition: right 0.3s;
        }

        .body {
            background-color: white !important;
        }
    </style>

  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\afitaporto\resources\views/about.blade.php ENDPATH**/ ?>