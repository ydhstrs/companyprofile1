@extends('main')

@section('contents')
    <header id="" class="py-28 text-center md:pt-36 lg:text-left ">
        <div class="container px-1 sm:px-8 lg:grid lg:grid-cols-2 lg:gap-x-8">
            <div class="mb-16 lg:mt-32 xl:mt-40 xl:mr-12">
                <h1 class=" text-primary1 md:text-xl lg:text-3xl col-start-1 font-Amiri font-light">
                    Hi! I'm Afita Puspa Sari

                </h1>
                <h1 class="block text-3xl mt-5 mb-2 text-primary1 md:text-2xl lg:text-4xl font-Akira">
                    UI/UX DESIGNER</h1>
                @foreach ($bio as $item)
                    <p class="text-gray-800 mb-10 font-Amiri text-lg">
                        {{ $item->text }}
                    </p>
                @endforeach
                @foreach ($about as $item)
                    <a href="https://mail.google.com/mail/u/0/?fs=1&tf=cm&to={{ $item->email }}" target="blank"
                        class="font-Amiri text-lg text-white bg-fourth1 py-1 px-9 rounded-xl hover:shadow-md hover:opacity-80 transition duration-500 ease-in-out">
                        Email Me</a>


                    <a href="{{ asset('storage/' . $item->cv) }}" download="resume-afita.pdf"
                        class="font-Amiri text-lg text-fourth1 underline underline-offset-4 py-1 px-9 hover:shadow-md hover:opacity-80 transition duration-500 ease-in-out">
                        Download CV
                    </a>
                @endforeach

                <div class="flex items-center mt-10">
                    <h4 class="font-Amiri font-normal text-slate-700 py-4 px-4">Check Out My : </h4>

                    @foreach ($about as $item)
                    <a href="https://{{ $item->instagram }}" target="_blank"
                        class="w-10 h-10 mr-3 rounded-full flex justify-center items-center
              text-slate-400 ">
                        <img class="h-10 self-center transition ease-in-out delay-150 hover:-translate-y-1 hover:scale-125 duration-300" src="/images/instagram.png" />
                    </a>
                    <a href="https://{{ $item->linkedin }}" target="_blank"
                        class="w-10 h-10 mr-3 rounded-full flex justify-center items-center
              text-slate-400 ">
                        <img class="h-10 self-center transition ease-in-out delay-150 hover:-translate-y-1 hover:scale-125 duration-300" src="/images/linkedin.png" />
                    </a>
                        <a href="https://{{ $item->tiktok }}" target="_blank"
                            class="w-10 h-10 mr-3 rounded-full flex justify-center items-center
                  text-slate-400 ">
                            <img class="h-10 self-center transition ease-in-out delay-150 hover:-translate-y-1 hover:scale-125 duration-300" src="/images/tiktok.png" />
                        </a>
                    @endforeach


                </div>
            </div>

            <div class="xl:text-right pt-20">
                @foreach ($banner as $item)
                    <img class="transition ease-in-out delay-150 hover:-translate-y-1 hover:scale-125 duration-300"
                        src="{{ asset('storage/' . $item->image) }}" alt="alternative" />
                @endforeach

            </div>
        </div> <!-- end of container -->
    </header> <!-- end of header -->


    <!-- Portofolio Section Start -->
    <section id="portofolio" class="pb-16 ">
        <div class="w-full">
            <div class="container px-1 sm:px-8 lg:grid lg:grid-cols-2 lg:gap-x-8">
                <h4 class="font-bold text-4xl text-primary1 mb-2 font-Akira">LATEST PROJECT</h4>
            </div>

        </div>
        <div class="w-full px-4 flex flex-wrap gap-10 justify-center lg:w-10/12 lg:mx-auto ">
            @foreach ($projects as $item)
                <div class="max-w-sm rounded overflow-hidden shadow-lg">

                    @if ($item->image)
                        <div class="place-items-center h-48 overflow-hidden m-4">

                            <img src="{{ asset('/storage/' . $item->image) }}" class="w-full ">
                        </div>
                    @else
                        <img class="w-full" src="https://source.unsplash.com/1200x600?forest" alt="Sunset in the mountains">
                    @endif

                    <div class="px-6 py-4">
                        <div class="font-bold text-xl mb-2 font-Akira">{{ $item->title }}</div>
                        <p class="text-gray-700 text-sm font-Amiri">
                            {{ $item->excerpt }}
                        </p>
                    </div>
                    <div class="pt-4 pb-2 px-6">
                        <a href="/work/{{ $item->slug }}"
                            class="rounded-full px-3 py-1 text-sm font-semibold text-fourth1 mr-2 mb-2 flex place-items-center transition ease-in-out delay-150 hover:-translate-y-1 hover:scale-210 duration-300">Case
                            Study <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" />
                            </svg>
                        </a>
                    </div>
                </div>
            @endforeach
    </section>
    <!-- Portofolio Section End -->


    <section id="strength" class="pb-16 ">

        </div>
        </div>
        <div class="flex flex-col items-center my-20">
            <a href="/works"
                class="font-Amiri text-lg max-w-xl mx-auto justify-center  text-white bg-fourth1 py-2 px-9 rounded-xl hover:shadow-md hover:opacity-80 transition duration-500 ease-in-out">
                View All Works</a>
        </div>

        <div class="mb-16">
            <h4 class="font-Akira text-4xl text-primary1 text-center mb-2">WHY HIRE ME?</h4>
        </div>
        <div class="lg:grid lg:grid-cols-4 lg:gap-1 lg:px-28 md:flex md:flex-row md:mx-auto md:text-center">
            @foreach ($strengths as $item)
                <div class="max-w-sm rounded overflow-hidden  items-center">
                    <img class="w-60 mx-auto" src="{{ asset('/storage/' . $item->image) }}" alt="Sunset in the mountains">
                    <div class="px-6 py-4">
                        <div class="font-bold text-xl mb-2 text-center text-gray-800 font-Akira">{{ $item->title }}</div>

                        <p class="text-gray-600 text-base text-center font-light font-Amiri">
                            {{ $item->isi }}
                        </p>
                    </div>

                </div>
            @endforeach
        </div>
        </div>
    </section>

    <section>
        <div class="lg:grid lg:grid-cols-3 lg:gap-4 md:flex md:flex-row md:mx-auto container px-1 sm:px-8 lg:gap-x-8">

            <div class="col-span-1">
                <h4 class="font-Akira text-lg text-gray-800 m-10">TESTIMONIAL</h4>
                <h1 class="font-Akira text-2xl text-primary1 mx-10">HAPPY</h1>
                <h1 class="font-Akira text-2xl text-primary1 mx-10">TEAM MATES'S FEEDBACK</h1>

            </div>
            <div class="col-span-2">
                <div class="gallery bg-primary2 rounded mx-auto m-5 " style="width:750px;">
                    <div class="top flex p-2 select-none">
                        <div class="buttons flex text-gray-600 ">
                            <svg action="prev" class="w-10 border-2 rounded-l-lg bg-white  p-1 cursor-pointer border-r-0"
                                xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke="currentColor">
                                <path action="prev" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                            </svg>
                            <svg action="next" class="w-10 border-2 rounded-r-lg p-1 bg-white cursor-pointer"
                                xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke="currentColor">
                                <path action="next" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M14 5l7 7m0 0l-7 7m7-7H3" />
                            </svg>
                        </div>
                        <div class="heading"></div>

                    </div>
                    <div class="content-area w-full h-96 overflow-hidden">
                        <div class="platform shadow-xl h-full flex">
                            <!-- frame start -->
                            @foreach ($testimonials as $item)
                                <div class="each-frame border-box flex-none h-full">
                                    <!-- this is full editable area -->
                                    <div class="main flex w-full p-8">
                                        <div class="sub my-auto mx-4">
                                            <img class="object-cover w-20 h-20 rounded-full"
                                                src="{{ asset('/storage/' . $item->image) }}" alt="">
                                        </div>
                                        <div class="my-auto left-2">
                                            <div class="head text-3xl font-bold text-primary1 font-Amiri">
                                                {{ $item->name }}</div>
                                            <div class="head text-md font-light mb-2 text-slate-700 font-Amiri">
                                                {{ $item->job }}
                                            </div>
                                        </div>
                                    </div>
                                    <div class="px-8">
                                        <div class="long-text font-Amiri text-md">{{ $item->isi }}</div>
                                    </div>
                                </div>
                            @endforeach
                            <!-- frame end -->
                        </div>
                    </div>
                </div>
            </div>


        </div>
        </div>

        </div>
        </div>
    </section>
    <section id="contact">

        <div class="py-16 min-w-full flex transition-all duration-500 bg-third1 pt-30">
            <div class="container max-w-screen-lg mx-auto">
                <div class="text-center">
                    <div class="">
                        <p class="text-2xl font-bold text-black mb-4 font-Akira">
                            GET IN TOUCH WITH ME, SAY HI
                        </p>
                        @foreach ($about as $item)
                            <a target="blank" href="https://mail.google.com/mail/u/0/?fs=1&tf=cm&to={{ $item->email }}"
                                class="text-2xl text-fourth1 underline underline-offset-8 font-Amiri font-semibold">
                                <ion-icon class="text-xl" name="mail-outline"></ion-icon>{{ $item->email }}
                            </a>
                        @endforeach
                    </div>

                </div>
                <hr class="my-6  sm:mx-auto text-white lg:my-8" />

            </div>
        </div>
    </section>
    <style>
        .platform {
            position: relative;
            transition: right 0.3s;
        }

        .body {
            background-color: white !important;
        }
    </style>

    <script>
        function gallery() {
            this.index = 0;
            this.load = function() {
                this.rootEl = document.querySelector(".gallery");
                this.platform = this.rootEl.querySelector(".platform");
                this.frames = this.platform.querySelectorAll(".each-frame");
                this.contentArea = this.rootEl.querySelector(".content-area");
                this.width = parseInt(this.rootEl.style.width);
                this.limit = {
                    start: 0,
                    end: this.frames.length - 1
                };
                this.frames.forEach(each => {
                    each.style.width = this.width + "px";
                });
                this.goto(this.index);
            }
            this.set_title = function() {
                this.rootEl.querySelector(".heading").innerText = this.frames[this.index].getAttribute("title");
            }
            this.next = function() {
                this.platform.style.right = this.width * ++this.index + "px";
                this.set_title();
            }
            this.prev = function() {
                this.platform.style.right = this.width * --this.index + "px";
                this.set_title();
            }
            this.goto = function(index) {
                this.platform.style.right = this.width * index + "px";
                this.index = index;
                this.set_title();
            }
            this.load();
        }
        var G = new gallery();
        G.rootEl.addEventListener("click", function(t) {
            var val = t.target.getAttribute("action");
            if (val == "next" && G.index != G.limit.end) {
                G.next();
            }
            if (val == "prev" && G.index != G.limit.start) {
                G.prev();
            }
            if (val == "goto") {
                let rv = t.target.getAttribute("goto");
                rv = rv == "end" ? G.limit.end : rv;
                G.goto(parseInt(rv));
            }
        });
        document.addEventListener("keyup", function(t) {
            var val = t.keyCode;
            if (val == 39 && G.index != G.limit.end) {
                G.next();
            }
            if (val == 37 && G.index != G.limit.start) {
                G.prev();
            }
        });

        // run G.load() if new data loaded with ajax
    </script>
@endsection
